//
//  ServiceConstants.swift
//  4See
//
//  Created by Gagan Arora on 19/03/21.
//

import Foundation

import UIKit

class ServiceConstants: NSObject {
    static let kMessage              = "Message"
    static let kError                = "error"
    static let kErrorDescription     = "ErrorDescription"
    static let kmessage              = "message"
    static let kstatus               = "status"
}
